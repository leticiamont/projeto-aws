// CORREÇÃO 1: Usar 'import' em vez de 'require'
import mysql from 'mysql2/promise';

// CORREÇÃO 2: Preencher com os dados reais (Hardcoded para o teste)
const dbConfig = {
    // Pegue este endereço no Console AWS > RDS > Conectividade
    host: 'db-avaliacao-project.c8rqsm8ks024.us-east-1.rds.amazonaws.com', 
    
    // O usuário que você colocou no main.tf (linha 108)
    user: 'dbadmin', 
    
    // A senha que você colocou no main.tf (linha 110)
    password: 'Anna*Leticia#', 
    
    // O nome do banco que criamos no SQL Workbench (USE ecommerce;)
    database: 'ecommerce', 
    
    connectTimeout: 10000
};

export const handler = async (event) => {
    let connection;
    try {
        console.log("Tentando conectar ao banco...");
        connection = await mysql.createConnection(dbConfig);
        console.log("Conectado!");
        
        // Pega a categoria da URL (ex: api.com/produtos?categoria=vestidos)
        const categoria = event.queryStringParameters ? event.queryStringParameters.categoria : null;
        
        let query = 'SELECT * FROM produtos';
        let params = [];

        if (categoria) {
            query += ' WHERE categoria = ?';
            params.push(categoria);
        }

        const [rows] = await connection.execute(query, params);

        return {
            statusCode: 200,
            headers: { 
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            body: JSON.stringify(rows),
        };
    } catch (error) {
        console.error("Erro na Lambda:", error);
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ 
                error: 'Erro ao buscar produtos', 
                details: error.message 
            }),
        };
    } finally {
        if (connection) await connection.end();
    }
};